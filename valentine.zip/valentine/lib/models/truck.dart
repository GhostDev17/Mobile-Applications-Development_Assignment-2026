import 'task.dart';

class Truck {
  String truckNumber;
  String driverName;
  String mileage;
  String condition;
  String issue;

  String status; // 👈 NEW

  List<Task> tasks;

  Truck({
    required this.truckNumber,
    required this.driverName,
    required this.mileage,
    required this.condition,
    required this.issue,
    required this.tasks,
    this.status = "Checked-In", // 👈 default
  });
}