class Task {
  String name;
  bool isDone;
  String note;

  Task({
    required this.name,
    this.isDone = false,
    this.note = '',
  });
}