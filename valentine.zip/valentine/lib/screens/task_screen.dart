import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/truck_provider.dart';

class TaskScreen extends StatelessWidget {
  final String truckId;

  const TaskScreen({super.key, required this.truckId});

  @override
  Widget build(BuildContext context) {
    final truckProvider = Provider.of<TruckProvider>(context);

    final truck = truckProvider.trucks.firstWhere(
      (t) => t.id == truckId,
    );

    return Scaffold(
      appBar: AppBar(
        title: Text(truck.truckNumber),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: DropdownButtonFormField<String>(
              value: truck.status,
              decoration: const InputDecoration(
                labelText: 'Update Status',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(
                  value: "Checked-In",
                  child: Text("Checked-In"),
                ),
                DropdownMenuItem(
                  value: "In Progress",
                  child: Text("In Progress"),
                ),
                DropdownMenuItem(
                  value: "Completed",
                  child: Text("Completed"),
                ),
              ],
              onChanged: (value) {
                if (value != null) {
                  truckProvider.updateStatus(truck.id, value);
                }
              },
            ),
          ),

          Expanded(
            child: ListView.builder(
              itemCount: truck.tasks.length,
              itemBuilder: (context, index) {
                final task = truck.tasks[index];

                return Card(
                  margin: const EdgeInsets.all(10),
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      children: [
                        CheckboxListTile(
                          title: Text(task.name),
                          value: task.isDone,
                          onChanged: (value) {
                            truckProvider.toggleTask(truck.id, index);
                          },
                        ),

                        TextField(
                          key: ValueKey(task.note),
                          controller: TextEditingController(
                            text: task.note,
                          ),
                          decoration: const InputDecoration(
                            labelText: 'Add Notes',
                            border: OutlineInputBorder(),
                          ),
                          onChanged: (value) {
                            truckProvider.updateTaskNote(
                              truck.id,
                              index,
                              value,
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}