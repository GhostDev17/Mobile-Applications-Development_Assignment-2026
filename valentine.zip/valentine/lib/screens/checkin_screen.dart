import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/truck.dart';
import '../providers/truck_provider.dart';
import '../models/task.dart';

class CheckInScreen extends StatefulWidget {
  const CheckInScreen({super.key});

  @override
  State<CheckInScreen> createState() => _CheckInScreenState();
}

class _CheckInScreenState extends State<CheckInScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController truckController = TextEditingController();
  final TextEditingController driverController = TextEditingController();
  final TextEditingController mileageController = TextEditingController();
  final TextEditingController conditionController = TextEditingController();
  final TextEditingController issueController = TextEditingController();

void submitForm() {
  if (_formKey.currentState!.validate()) {
    final newTruck = Truck(
  truckNumber: truckController.text,
  driverName: driverController.text,
  mileage: mileageController.text,
  condition: conditionController.text,
  issue: issueController.text,
  tasks: [
    Task(name: "Oil Change"),
    Task(name: "Brake Inspection"),
    Task(name: "Tire Check"),
    Task(name: "Engine Diagnostics"),
  ],
);

    Provider.of<TruckProvider>(context, listen: false)
        .addTruck(newTruck);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Truck Checked-In Successfully')),
    );

    truckController.clear();
    driverController.clear();
    mileageController.clear();
    conditionController.clear();
    issueController.clear();
  }
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Truck Check-In'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: truckController,
                decoration: const InputDecoration(
                  labelText: 'Truck Number',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Enter truck number' : null,
              ),
              const SizedBox(height: 15),

              TextFormField(
                controller: driverController,
                decoration: const InputDecoration(
                  labelText: 'Driver Name',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Enter driver name' : null,
              ),
              const SizedBox(height: 15),

              TextFormField(
                controller: mileageController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Mileage (KM)',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Enter mileage' : null,
              ),
              const SizedBox(height: 15),

              TextFormField(
                controller: conditionController,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'Vehicle Condition',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Enter condition' : null,
              ),
              const SizedBox(height: 15),

              TextFormField(
                controller: issueController,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'Reported Issue',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Enter issue' : null,
              ),
              const SizedBox(height: 20),

              ElevatedButton(
                onPressed: submitForm,
                child: const Text('Check-In Truck'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}