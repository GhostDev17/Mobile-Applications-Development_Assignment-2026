import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/truck_provider.dart';
import 'checkin_screen.dart';
import 'repairs_screen.dart';
import 'reports_screen.dart';

class HomeScreen extends StatefulWidget {
  final String role;

  const HomeScreen({
    super.key,
    required this.role,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  @override
  void initState() {
    super.initState();

    Future.delayed(Duration.zero, () {
      Provider.of<TruckProvider>(
        context,
        listen: false,
      ).loadTrucks();
    });
  }

  int currentIndex = 0;

  List<Widget> getScreens() {
    if (widget.role == "Admin") {
      return const [
        CheckInScreen(),
        RepairsScreen(),
        ReportsScreen(),
      ];
    }

    if (widget.role == "Mechanic") {
      return const [
        RepairsScreen(),
      ];
    }

    if (widget.role == "Reception") {
      return const [
        CheckInScreen(),
      ];
    }

    return const [
      CheckInScreen(),
    ];
  }

  List<BottomNavigationBarItem> getNavItems() {
    if (widget.role == "Admin") {
      return const [
        BottomNavigationBarItem(
          icon: Icon(Icons.car_repair),
          label: 'Check-In',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.build),
          label: 'Repairs',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.bar_chart),
          label: 'Reports',
        ),
      ];
    }

    if (widget.role == "Mechanic") {
      return const [
        BottomNavigationBarItem(
          icon: Icon(Icons.build),
          label: 'Repairs',
        ),
      ];
    }

    return const [
      BottomNavigationBarItem(
        icon: Icon(Icons.car_repair),
        label: 'Check-In',
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final trucks = Provider.of<TruckProvider>(context).trucks;

    int totalTrucks = trucks.length;

    int activeRepairs =
        trucks.where((t) => t.status == "In Progress").length;

    int completedTasks = trucks
        .expand((t) => t.tasks)
        .where((task) => task.isDone)
        .length;

    final screens = getScreens();

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        elevation: 2,
        title: Text(
          "Valentine Garage (${widget.role})",
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),

      body: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildCard("Trucks", totalTrucks, Colors.blue),
                _buildCard("Active", activeRepairs, Colors.orange),
                _buildCard("Done", completedTasks, Colors.green),
              ],
            ),

            const SizedBox(height: 10),

            Expanded(
              child: screens[currentIndex],
            ),
          ],
        ),
      ),

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        items: getNavItems(),
        onTap: (index) {
          setState(() {
            currentIndex = index;
          });
        },
      ),
    );
  }

  Widget _buildCard(String title, int value, Color color) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      child: Container(
        width: 110,
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Text(
              value.toString(),
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              title,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}