import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/truck_provider.dart';
import '../utils/status_utils.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final trucks = Provider.of<TruckProvider>(context).trucks;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Reports'),
      ),
      body: trucks.isEmpty
          ? const Center(
              child: Text(
                'No reports available',
                style: TextStyle(fontSize: 18),
              ),
            )
          : ListView.builder(
              itemCount: trucks.length,
              itemBuilder: (context, index) {
                final truck = trucks[index];

                int completedTasks = truck.tasks
                    .where((task) => task.isDone)
                    .length;

                int totalTasks = truck.tasks.length;

                return Card(
                  margin: const EdgeInsets.all(10),
                  child: ExpansionTile(
                    title: Text(truck.truckNumber),
subtitle: Column(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
    Text("Driver: ${truck.driverName}"),
    Text("Mileage: ${truck.mileage} km"),
    Text("Issue: ${truck.issue}"),
    const SizedBox(height: 5),
    Text(
      "Progress: $completedTasks / $totalTasks tasks completed",
      style: const TextStyle(fontWeight: FontWeight.bold),
    ),

    Container(
  padding: const EdgeInsets.symmetric(
    horizontal: 10,
    vertical: 5,
  ),
  decoration: BoxDecoration(
    color: StatusUtils.getStatusColor(truck.status),
    borderRadius: BorderRadius.circular(20),
  ),
  child: Text(
    truck.status,
    style: const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.bold,
    ),
  ),
),
  ],
),
                    children: [
  Padding(
    padding: const EdgeInsets.all(10),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Vehicle Condition:",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        Text(truck.condition),
        const SizedBox(height: 10),

        ...truck.tasks.map((task) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "${task.name} - ${task.isDone ? 'Done' : 'Pending'}",
                style: const TextStyle(fontSize: 16),
              ),
              if (task.note.isNotEmpty)
                Text(
                  "Note: ${task.note}",
                  style: const TextStyle(color: Colors.grey),
                ),
              const Divider(),
            ],
          );
        }).toList(),
      ],
    ),
  )
],
                  ),
                );
              },
            ),
    );
  }
} 