import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/truck_provider.dart';
import 'task_screen.dart';
import '../utils/status_utils.dart';

class RepairsScreen extends StatelessWidget {
  const RepairsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final trucks = Provider.of<TruckProvider>(context).trucks;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Repairs'),
      ),
      body: trucks.isEmpty
          ? const Center(
              child: Text(
                'No trucks checked-in yet',
                style: TextStyle(fontSize: 18),
              ),
            )
          : ListView.builder(
              itemCount: trucks.length,
              itemBuilder: (context, index) {
                final truck = trucks[index];

               return Card(
  margin: const EdgeInsets.all(10),
  child: ListTile(
    title: Text(truck.truckNumber),
    subtitle: Column(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
    Text("Driver: ${truck.driverName}"),
    Text("Issue: ${truck.issue}"),

    const SizedBox(height: 5),

    Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 8,
        vertical: 4,
      ),
      decoration: BoxDecoration(
        color: StatusUtils.getStatusColor(truck.status),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Text(
        truck.status,
        style: const TextStyle(
          color: Colors.white,
        ),
      ),
    ),
  ],
),
    trailing: const Icon(Icons.arrow_forward),
    onTap: () {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => TaskScreen(truckIndex: index),
        ),
      );
    },
  ),
);
              },
            ),
    );
  }
}