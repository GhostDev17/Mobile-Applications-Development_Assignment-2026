import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/truck.dart';
import '../models/task.dart';

class TruckProvider with ChangeNotifier {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  List<Truck> _trucks = [];
  List<Truck> get trucks => _trucks;

  // 🔥 REAL-TIME STREAM (FOR HOME SCREEN)
  Stream<List<Truck>> getTrucksStream() {
    return _db
        .collection('trucks')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        final data = doc.data();

        return Truck(
          id: doc.id,
          truckNumber: data['truckNumber'] ?? '',
          driverName: data['driverName'] ?? '',
          mileage: data['mileage'] ?? '',
          condition: data['condition'] ?? '',
          issue: data['issue'] ?? '',
          status: data['status'] ?? 'Checked-In',
          tasks: (data['tasks'] as List<dynamic>? ?? [])
              .map((t) => Task(
                    name: t['name'] ?? '',
                    isDone: t['isDone'] ?? false,
                    note: t['note'] ?? '',
                  ))
              .toList(),
        );
      }).toList();
    });
  }

  // 🔥 ADD TRUCK
  Future<void> addTruck({
    required String truckNumber,
    required String driverName,
    required String mileage,
    required String condition,
    required String issue,
  }) async {
    await _db.collection('trucks').add({
      'truckNumber': truckNumber,
      'driverName': driverName,
      'mileage': mileage,
      'condition': condition,
      'issue': issue,
      'status': 'Checked-In',
      'tasks': [
        {'name': 'Oil Change', 'isDone': false, 'note': ''},
        {'name': 'Brake Inspection', 'isDone': false, 'note': ''},
        {'name': 'Tire Check', 'isDone': false, 'note': ''},
        {'name': 'Engine Diagnostics', 'isDone': false, 'note': ''},
      ],
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  // 🔥 UPDATE STATUS
  Future<void> updateStatus(String truckId, String status) async {
    await _db.collection('trucks').doc(truckId).update({
      'status': status,
    });
  }

  // 🔥 TOGGLE TASK
  Future<void> toggleTask(String truckId, int taskIndex) async {
    final doc = await _db.collection('trucks').doc(truckId).get();
    final data = doc.data()!;

    List tasks = data['tasks'];

    tasks[taskIndex]['isDone'] = !tasks[taskIndex]['isDone'];

    await _db.collection('trucks').doc(truckId).update({
      'tasks': tasks,
    });
  }

  // 🔥 UPDATE TASK NOTE
  Future<void> updateTaskNote(
      String truckId, int taskIndex, String note) async {
    final doc = await _db.collection('trucks').doc(truckId).get();
    final data = doc.data()!;

    List tasks = data['tasks'];

    tasks[taskIndex]['note'] = note;

    await _db.collection('trucks').doc(truckId).update({
      'tasks': tasks,
    });
  }
}