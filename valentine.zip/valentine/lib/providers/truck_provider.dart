import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/truck.dart';

class TruckProvider with ChangeNotifier {
  final List<Truck> _trucks = [];

  List<Truck> get trucks => _trucks;

  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // 🔥 LOAD FROM FIREBASE
  Future<void> loadTrucks() async {
  try {
    final snapshot =
        await _db.collection('trucks').orderBy('createdAt', descending: true).get();

    _trucks.clear();

    for (var doc in snapshot.docs) {
      _trucks.add(
        Truck(
          truckNumber: doc['truckNumber'] ?? '',
          driverName: doc['driverName'] ?? '',
          mileage: doc['mileage'] ?? 0,
          condition: doc['condition'] ?? '',
          issue: doc['issue'] ?? '',
          status: doc['status'] ?? 'Checked-In',
          tasks: [],
        ),
      );
    }

    notifyListeners();
  } catch (e) {
    debugPrint("Error loading trucks: $e");
  }
}

  // 🔥 ADD TRUCK TO FIREBASE
 Future<void> addTruck(Truck truck) async {
  try {
    await _db.collection('trucks').add({
      'truckNumber': truck.truckNumber,
      'driverName': truck.driverName,
      'mileage': truck.mileage,
      'condition': truck.condition,
      'issue': truck.issue,
      'status': truck.status,
      'createdAt': FieldValue.serverTimestamp(),
    });

    _trucks.add(truck);
    notifyListeners();
  } catch (e) {
    debugPrint("Error adding truck: $e");
  }
}

  void toggleTask(int truckIndex, int taskIndex) {
    _trucks[truckIndex].tasks[taskIndex].isDone =
        !_trucks[truckIndex].tasks[taskIndex].isDone;

    notifyListeners();
  }

  void updateTaskNote(int truckIndex, int taskIndex, String note) {
    _trucks[truckIndex].tasks[taskIndex].note = note;
    notifyListeners();
  }

  void updateStatus(int truckIndex, String status) {
    _trucks[truckIndex].status = status;
    notifyListeners();
  }
}