import 'package:flutter/material.dart';

class StatusUtils {
  static Color getStatusColor(String status) {
    switch (status) {
      case "Checked-In":
        return Colors.red;

      case "In Progress":
        return Colors.orange;

      case "Completed":
        return Colors.green;

      default:
        return Colors.grey;
    }
  }
}